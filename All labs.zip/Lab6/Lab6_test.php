<?php
$mensaje = "Hello, World!";
$suma = 2 + 3;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Lab6</title>
</head>
<body>
    <?php
    echo "<h1>$mensaje</h1>";
    echo "<h2>$suma</h2>";
    ?>
</body>
</html>
